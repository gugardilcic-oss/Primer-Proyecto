package com.duoc.saludconecta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaludconectaApplicationTests {

	@Test
	void contextLoads() {
	}

}
