package com.duoc.biblioteca.repository;
import com.duoc.biblioteca.model.farmaco;
import org.springframework.stereotype.repository;

import java.util.Arraylist;
import java.util.list;

@repository

public class FarmacoRepository() {

}

pricate final list <Farmaco> listaFarmaco =  new Arraylist <>();

public list<Farmaco> ObtenerTodo() {
    return listaFarmaco;
}

    